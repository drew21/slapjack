﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.butPause = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.but_Slap = new System.Windows.Forms.Button();
            this.lblPlayer1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblScore = new System.Windows.Forms.Label();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.lblPlayer2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtScore2 = new System.Windows.Forms.TextBox();
            this.lblWinner = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lblPlayer3 = new System.Windows.Forms.Label();
            this.lblPlayer4 = new System.Windows.Forms.Label();
            this.txtScore3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtScore4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.p2PicBox = new System.Windows.Forms.PictureBox();
            this.p1PicBox = new System.Windows.Forms.PictureBox();
            this.p3PicBox = new System.Windows.Forms.PictureBox();
            this.p4PicBox = new System.Windows.Forms.PictureBox();
            this.pl2pb1 = new System.Windows.Forms.PictureBox();
            this.pl2pb2 = new System.Windows.Forms.PictureBox();
            this.pl2pb3 = new System.Windows.Forms.PictureBox();
            this.pl3pb1 = new System.Windows.Forms.PictureBox();
            this.pl3pb2 = new System.Windows.Forms.PictureBox();
            this.pl3pb3 = new System.Windows.Forms.PictureBox();
            this.pl1pb1 = new System.Windows.Forms.PictureBox();
            this.pl1pb2 = new System.Windows.Forms.PictureBox();
            this.pl1pb3 = new System.Windows.Forms.PictureBox();
            this.pl4pb1 = new System.Windows.Forms.PictureBox();
            this.pl4pb2 = new System.Windows.Forms.PictureBox();
            this.pl4pb3 = new System.Windows.Forms.PictureBox();
            this.newGamebut = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2PicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1PicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3PicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4PicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl2pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl2pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl2pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl3pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl3pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl3pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl1pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl1pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl1pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl4pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl4pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl4pb3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(497, 202);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // butPause
            // 
            this.butPause.Location = new System.Drawing.Point(443, 360);
            this.butPause.Name = "butPause";
            this.butPause.Size = new System.Drawing.Size(90, 30);
            this.butPause.TabIndex = 1;
            this.butPause.Text = "Pause";
            this.butPause.UseVisualStyleBackColor = true;
            this.butPause.Click += new System.EventHandler(this.butPause_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(671, 359);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 27);
            this.button2.TabIndex = 2;
            this.button2.Text = "End Game";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.butEndGame_Click);
            // 
            // but_Slap
            // 
            this.but_Slap.Location = new System.Drawing.Point(313, 360);
            this.but_Slap.Name = "but_Slap";
            this.but_Slap.Size = new System.Drawing.Size(90, 29);
            this.but_Slap.TabIndex = 3;
            this.but_Slap.Text = "Slap";
            this.but_Slap.UseVisualStyleBackColor = true;
            this.but_Slap.Click += new System.EventHandler(this.but_Slap_Click);
            // 
            // lblPlayer1
            // 
            this.lblPlayer1.AutoSize = true;
            this.lblPlayer1.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPlayer1.Location = new System.Drawing.Point(620, 398);
            this.lblPlayer1.Name = "lblPlayer1";
            this.lblPlayer1.Size = new System.Drawing.Size(85, 24);
            this.lblPlayer1.TabIndex = 4;
            this.lblPlayer1.Text = "Player 1";
            this.lblPlayer1.Click += new System.EventHandler(this.lblPlayer1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(472, 411);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(123, 130);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.BackColor = System.Drawing.Color.Transparent;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblScore.Location = new System.Drawing.Point(629, 429);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(65, 24);
            this.lblScore.TabIndex = 6;
            this.lblScore.Text = "Score";
            // 
            // txtScore
            // 
            this.txtScore.Location = new System.Drawing.Point(633, 470);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(64, 20);
            this.txtScore.TabIndex = 7;
            this.txtScore.Text = "0";
            // 
            // lblPlayer2
            // 
            this.lblPlayer2.AutoSize = true;
            this.lblPlayer2.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPlayer2.Location = new System.Drawing.Point(362, 13);
            this.lblPlayer2.Name = "lblPlayer2";
            this.lblPlayer2.Size = new System.Drawing.Size(85, 24);
            this.lblPlayer2.TabIndex = 8;
            this.lblPlayer2.Text = "Player 2";
            this.lblPlayer2.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(472, 9);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(137, 130);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(373, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Score";
            // 
            // txtScore2
            // 
            this.txtScore2.Location = new System.Drawing.Point(377, 90);
            this.txtScore2.Name = "txtScore2";
            this.txtScore2.Size = new System.Drawing.Size(62, 20);
            this.txtScore2.TabIndex = 11;
            this.txtScore2.Text = "0";
            // 
            // lblWinner
            // 
            this.lblWinner.AutoSize = true;
            this.lblWinner.BackColor = System.Drawing.Color.Transparent;
            this.lblWinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWinner.ForeColor = System.Drawing.SystemColors.Window;
            this.lblWinner.Location = new System.Drawing.Point(572, 190);
            this.lblWinner.Name = "lblWinner";
            this.lblWinner.Size = new System.Drawing.Size(0, 24);
            this.lblWinner.TabIndex = 12;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::WindowsFormsApplication1.Properties.Resources.cat;
            this.pictureBox4.Location = new System.Drawing.Point(32, 190);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(147, 138);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(898, 190);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(150, 131);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // lblPlayer3
            // 
            this.lblPlayer3.AutoSize = true;
            this.lblPlayer3.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPlayer3.Location = new System.Drawing.Point(56, 144);
            this.lblPlayer3.Name = "lblPlayer3";
            this.lblPlayer3.Size = new System.Drawing.Size(85, 24);
            this.lblPlayer3.TabIndex = 15;
            this.lblPlayer3.Text = "Player 3";
            this.lblPlayer3.Visible = false;
            // 
            // lblPlayer4
            // 
            this.lblPlayer4.AutoSize = true;
            this.lblPlayer4.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPlayer4.Location = new System.Drawing.Point(946, 154);
            this.lblPlayer4.Name = "lblPlayer4";
            this.lblPlayer4.Size = new System.Drawing.Size(85, 24);
            this.lblPlayer4.TabIndex = 16;
            this.lblPlayer4.Text = "Player 4";
            this.lblPlayer4.Visible = false;
            // 
            // txtScore3
            // 
            this.txtScore3.Location = new System.Drawing.Point(66, 360);
            this.txtScore3.Name = "txtScore3";
            this.txtScore3.Size = new System.Drawing.Size(64, 20);
            this.txtScore3.TabIndex = 18;
            this.txtScore3.Text = "0";
            this.txtScore3.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(65, 333);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 24);
            this.label3.TabIndex = 17;
            this.label3.Text = "Score";
            this.label3.Visible = false;
            // 
            // txtScore4
            // 
            this.txtScore4.Location = new System.Drawing.Point(950, 372);
            this.txtScore4.Name = "txtScore4";
            this.txtScore4.Size = new System.Drawing.Size(64, 20);
            this.txtScore4.TabIndex = 20;
            this.txtScore4.Text = "0";
            this.txtScore4.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(946, 333);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 24);
            this.label4.TabIndex = 19;
            this.label4.Text = "Score";
            this.label4.Visible = false;
            // 
            // p2PicBox
            // 
            this.p2PicBox.Location = new System.Drawing.Point(633, 26);
            this.p2PicBox.Name = "p2PicBox";
            this.p2PicBox.Size = new System.Drawing.Size(95, 113);
            this.p2PicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p2PicBox.TabIndex = 21;
            this.p2PicBox.TabStop = false;
            // 
            // p1PicBox
            // 
            this.p1PicBox.Location = new System.Drawing.Point(357, 411);
            this.p1PicBox.Name = "p1PicBox";
            this.p1PicBox.Size = new System.Drawing.Size(96, 112);
            this.p1PicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p1PicBox.TabIndex = 22;
            this.p1PicBox.TabStop = false;
            this.p1PicBox.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // p3PicBox
            // 
            this.p3PicBox.Location = new System.Drawing.Point(185, 202);
            this.p3PicBox.Name = "p3PicBox";
            this.p3PicBox.Size = new System.Drawing.Size(91, 116);
            this.p3PicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p3PicBox.TabIndex = 23;
            this.p3PicBox.TabStop = false;
            this.p3PicBox.Visible = false;
            // 
            // p4PicBox
            // 
            this.p4PicBox.Location = new System.Drawing.Point(792, 202);
            this.p4PicBox.Name = "p4PicBox";
            this.p4PicBox.Size = new System.Drawing.Size(100, 115);
            this.p4PicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p4PicBox.TabIndex = 24;
            this.p4PicBox.TabStop = false;
            this.p4PicBox.Visible = false;
            // 
            // pl2pb1
            // 
            this.pl2pb1.Location = new System.Drawing.Point(652, 26);
            this.pl2pb1.Name = "pl2pb1";
            this.pl2pb1.Size = new System.Drawing.Size(103, 112);
            this.pl2pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl2pb1.TabIndex = 25;
            this.pl2pb1.TabStop = false;
            // 
            // pl2pb2
            // 
            this.pl2pb2.Location = new System.Drawing.Point(677, 25);
            this.pl2pb2.Name = "pl2pb2";
            this.pl2pb2.Size = new System.Drawing.Size(120, 113);
            this.pl2pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl2pb2.TabIndex = 26;
            this.pl2pb2.TabStop = false;
            this.pl2pb2.Click += new System.EventHandler(this.pictureBox7_Click_1);
            // 
            // pl2pb3
            // 
            this.pl2pb3.Location = new System.Drawing.Point(698, 27);
            this.pl2pb3.Name = "pl2pb3";
            this.pl2pb3.Size = new System.Drawing.Size(99, 112);
            this.pl2pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl2pb3.TabIndex = 27;
            this.pl2pb3.TabStop = false;
            // 
            // pl3pb1
            // 
            this.pl3pb1.Location = new System.Drawing.Point(202, 202);
            this.pl3pb1.Name = "pl3pb1";
            this.pl3pb1.Size = new System.Drawing.Size(103, 115);
            this.pl3pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl3pb1.TabIndex = 29;
            this.pl3pb1.TabStop = false;
            this.pl3pb1.Visible = false;
            // 
            // pl3pb2
            // 
            this.pl3pb2.Location = new System.Drawing.Point(224, 202);
            this.pl3pb2.Name = "pl3pb2";
            this.pl3pb2.Size = new System.Drawing.Size(99, 116);
            this.pl3pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl3pb2.TabIndex = 30;
            this.pl3pb2.TabStop = false;
            this.pl3pb2.Visible = false;
            this.pl3pb2.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pl3pb3
            // 
            this.pl3pb3.Location = new System.Drawing.Point(241, 202);
            this.pl3pb3.Name = "pl3pb3";
            this.pl3pb3.Size = new System.Drawing.Size(99, 116);
            this.pl3pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl3pb3.TabIndex = 31;
            this.pl3pb3.TabStop = false;
            this.pl3pb3.Visible = false;
            // 
            // pl1pb1
            // 
            this.pl1pb1.Location = new System.Drawing.Point(330, 411);
            this.pl1pb1.Name = "pl1pb1";
            this.pl1pb1.Size = new System.Drawing.Size(99, 112);
            this.pl1pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl1pb1.TabIndex = 32;
            this.pl1pb1.TabStop = false;
            // 
            // pl1pb2
            // 
            this.pl1pb2.Location = new System.Drawing.Point(304, 411);
            this.pl1pb2.Name = "pl1pb2";
            this.pl1pb2.Size = new System.Drawing.Size(99, 112);
            this.pl1pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl1pb2.TabIndex = 33;
            this.pl1pb2.TabStop = false;
            // 
            // pl1pb3
            // 
            this.pl1pb3.Location = new System.Drawing.Point(282, 411);
            this.pl1pb3.Name = "pl1pb3";
            this.pl1pb3.Size = new System.Drawing.Size(99, 112);
            this.pl1pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl1pb3.TabIndex = 34;
            this.pl1pb3.TabStop = false;
            // 
            // pl4pb1
            // 
            this.pl4pb1.Location = new System.Drawing.Point(776, 202);
            this.pl4pb1.Name = "pl4pb1";
            this.pl4pb1.Size = new System.Drawing.Size(100, 116);
            this.pl4pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl4pb1.TabIndex = 35;
            this.pl4pb1.TabStop = false;
            this.pl4pb1.Visible = false;
            // 
            // pl4pb2
            // 
            this.pl4pb2.Location = new System.Drawing.Point(759, 202);
            this.pl4pb2.Name = "pl4pb2";
            this.pl4pb2.Size = new System.Drawing.Size(100, 115);
            this.pl4pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl4pb2.TabIndex = 36;
            this.pl4pb2.TabStop = false;
            this.pl4pb2.Visible = false;
            // 
            // pl4pb3
            // 
            this.pl4pb3.Location = new System.Drawing.Point(741, 202);
            this.pl4pb3.Name = "pl4pb3";
            this.pl4pb3.Size = new System.Drawing.Size(101, 116);
            this.pl4pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pl4pb3.TabIndex = 37;
            this.pl4pb3.TabStop = false;
            this.pl4pb3.Visible = false;
            // 
            // newGamebut
            // 
            this.newGamebut.Location = new System.Drawing.Point(560, 359);
            this.newGamebut.Name = "newGamebut";
            this.newGamebut.Size = new System.Drawing.Size(90, 30);
            this.newGamebut.TabIndex = 38;
            this.newGamebut.Text = "New Game";
            this.newGamebut.UseVisualStyleBackColor = true;
            this.newGamebut.Click += new System.EventHandler(this.newGamebut_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.wood1;
            this.ClientSize = new System.Drawing.Size(1084, 553);
            this.Controls.Add(this.newGamebut);
            this.Controls.Add(this.pl4pb3);
            this.Controls.Add(this.pl4pb2);
            this.Controls.Add(this.pl4pb1);
            this.Controls.Add(this.pl1pb3);
            this.Controls.Add(this.pl1pb2);
            this.Controls.Add(this.pl1pb1);
            this.Controls.Add(this.pl3pb3);
            this.Controls.Add(this.pl3pb2);
            this.Controls.Add(this.pl3pb1);
            this.Controls.Add(this.pl2pb3);
            this.Controls.Add(this.pl2pb2);
            this.Controls.Add(this.pl2pb1);
            this.Controls.Add(this.p4PicBox);
            this.Controls.Add(this.p3PicBox);
            this.Controls.Add(this.p1PicBox);
            this.Controls.Add(this.p2PicBox);
            this.Controls.Add(this.txtScore4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtScore3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblPlayer4);
            this.Controls.Add(this.lblPlayer3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.lblWinner);
            this.Controls.Add(this.txtScore2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.lblPlayer2);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblPlayer1);
            this.Controls.Add(this.but_Slap);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.butPause);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Slap Jack";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2PicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1PicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3PicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4PicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl2pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl2pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl2pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl3pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl3pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl3pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl1pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl1pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl1pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl4pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl4pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pl4pb3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button butPause;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button but_Slap;
        private System.Windows.Forms.Label lblPlayer1;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox txtScore;
        private System.Windows.Forms.Label lblPlayer2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtScore2;
        private System.Windows.Forms.Label lblWinner;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblPlayer3;
        private System.Windows.Forms.Label lblPlayer4;
        public System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtScore3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtScore4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox p2PicBox;
        private System.Windows.Forms.PictureBox p1PicBox;
        private System.Windows.Forms.PictureBox p3PicBox;
        private System.Windows.Forms.PictureBox p4PicBox;
        private System.Windows.Forms.PictureBox pl2pb1;
        private System.Windows.Forms.PictureBox pl2pb2;
        private System.Windows.Forms.PictureBox pl2pb3;
        private System.Windows.Forms.PictureBox pl3pb1;
        private System.Windows.Forms.PictureBox pl3pb2;
        private System.Windows.Forms.PictureBox pl3pb3;
        private System.Windows.Forms.PictureBox pl1pb1;
        private System.Windows.Forms.PictureBox pl1pb2;
        private System.Windows.Forms.PictureBox pl1pb3;
        private System.Windows.Forms.PictureBox pl4pb1;
        private System.Windows.Forms.PictureBox pl4pb2;
        private System.Windows.Forms.PictureBox pl4pb3;
        private System.Windows.Forms.Button newGamebut;
        private System.Windows.Forms.Timer timer1;
    }
}